[Building a PDF Question-Answering App with LangChain and Ollama: A Beginner’s Guide](https://medium.com/@armandaneshdoost/building-a-pdf-question-answering-app-with-langchain-and-ollama-a-beginners-guide-b8e3e062787a)


$ sudo apt-get install python3-full

$ python3 -m venv venv
$ source venv/bin/activate


pip install langchain langchain-community langchain-ollama langchain-chroma streamlit pypdf


$ streamlit run app.py